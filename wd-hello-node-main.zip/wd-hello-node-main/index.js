const hello = () => {
  console.log("Hello Node.js! Trying it for the first time");
}
hello();
